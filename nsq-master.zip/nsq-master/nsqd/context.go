package nsqd

type context struct {
	nsqd *NSQD
}
