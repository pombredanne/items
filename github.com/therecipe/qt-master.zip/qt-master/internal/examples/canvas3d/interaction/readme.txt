3D Models and textures used in the example courtesy of http://nobiax.deviantart.com/

See 3dmodels.txt for more information about the models.