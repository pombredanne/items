package cfiles

var DEMO bool

const DEMO_FILES = `
[
   {
      "Name":"testfile4",
      "Size":"52.43 MB",
      "Redundancy":"1.4x",
      "Available":true,
      "ProgressText":"48.33%",
      "ProgressValue":48.333333333333336,
      "Error":""
   },
   {
      "Name":"testfile5",
      "Size":"52.43 MB",
      "Redundancy":"0.0x",
      "Available":false,
      "ProgressText":"10.00%",
      "ProgressValue":10,
      "Error":""
   },
   {
      "Name":"testfile6",
      "Size":"52.43 MB",
      "Redundancy":"0.0x",
      "Available":false,
      "ProgressText":"20.00%",
      "ProgressValue":20,
      "Error":""
   },
   {
      "Name":"testfile7",
      "Size":"52.43 MB",
      "Redundancy":"0.0x",
      "Available":false,
      "ProgressText":"25.00%",
      "ProgressValue":25,
      "Error":""
   },
   {
      "Name":"testfile8",
      "Size":"52.43 MB",
      "Redundancy":"0.0x",
      "Available":false,
      "ProgressText":"20.00%",
      "ProgressValue":20,
      "Error":""
   },
   {
      "Name":"testfile9",
      "Size":"52.43 MB",
      "Redundancy":"0.0x",
      "Available":false,
      "ProgressText":"0.00%",
      "ProgressValue":0,
      "Error":""
   },
   {
      "Name":"testfolder/testfile1",
      "Size":"52.43 MB",
      "Redundancy":"1.5x",
      "Available":true,
      "ProgressText":"50.00%",
      "ProgressValue":50,
      "Error":""
   },
   {
      "Name":"testfolder/testfile2",
      "Size":"52.43 MB",
      "Redundancy":"1.5x",
      "Available":true,
      "ProgressText":"50.00%",
      "ProgressValue":50,
      "Error":""
   },
   {
      "Name":"testfolder/testfile3",
      "Size":"52.43 MB",
      "Redundancy":"1.5x",
      "Available":true,
      "ProgressText":"50.00%",
      "ProgressValue":50,
      "Error":""
   }
]`
