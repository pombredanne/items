<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>AboutPage</name>
    <message>
        <location filename="../pages/AboutPage.qml" line="27"/>
        <source>About this APP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="36"/>
        <source>Example APP demonstrating Qt Quick Controls 2

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="44"/>
        <source>This Example APP is part of a Blog Series and developed by ekke (@ekkescorner)

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="54"/>
        <source>About is a normal Page.
Navigation Drawer can be opened swiping from left or tapping on Menu Button.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="63"/>
        <source>Activation Policy: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="70"/>
        <source>WHILE SELECTED</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="85"/>
        <source>Init done from ABOUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="89"/>
        <source>Cleanup done from ABOUT</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AccentColorPage</name>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="23"/>
        <source>Select Material Accent Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="69"/>
        <source>Material Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="70"/>
        <source>Material Pink</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="71"/>
        <source>Material Purple</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="72"/>
        <source>Material DeepPurple</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="73"/>
        <source>Material Indigo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="74"/>
        <source>Material Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="75"/>
        <source>Material LightBlue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="76"/>
        <source>Material Cyan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="77"/>
        <source>Material Teal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="78"/>
        <source>Material Green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="79"/>
        <source>Material LightGreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="80"/>
        <source>Material Lime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="81"/>
        <source>Material Yellow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="82"/>
        <source>Material Amber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="83"/>
        <source>Material Orange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="84"/>
        <source>Material DeepOrange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="85"/>
        <source>Material Brown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="86"/>
        <source>Material Grey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="87"/>
        <source>Material BlueGrey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="98"/>
        <source>Init AccentColorPage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/AccentColorPage.qml" line="102"/>
        <source>Cleanup AccentColorPage</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HomePage</name>
    <message>
        <location filename="../pages/HomePage.qml" line="26"/>
        <source>The Home Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/HomePage.qml" line="37"/>
        <source>This Page is on a StackView - want to push another Page on top ?
Tap on the &apos;Qt&apos; Logo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/HomePage.qml" line="64"/>
        <source>Example APP demonstrating Qt Quick Controls 2

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/HomePage.qml" line="73"/>
        <source>Home Page is a StackView.
Navigation Drawer can be opened swiping from left or tapping on Menu Button.
Home Page is marked as Favority, so you can also navigate from Bottom (in Portrait Mode)
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/HomePage.qml" line="82"/>
        <source>Activation Policy: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/HomePage.qml" line="89"/>
        <source>IMMEDIATELY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/HomePage.qml" line="104"/>
        <source>Init done from Home Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/HomePage.qml" line="108"/>
        <source>Cleanup done from Home Page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InitialItemPage</name>
    <message>
        <location filename="../pages/InitialItemPage.qml" line="33"/>
        <source>Init done from InitialItemPage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/InitialItemPage.qml" line="37"/>
        <source>Cleanup done from InitialItemPage</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageFive</name>
    <message>
        <location filename="../pages/PageFive.qml" line="25"/>
        <source>Take the next Flight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageFive.qml" line="47"/>
        <source>Example APP demonstrating Qt Quick Controls 2

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageFive.qml" line="55"/>
        <source>Flight is a normal Page and has a Marker visible in Drawer.
Navigation Drawer can be opened swiping from left or tapping on Menu Button.
Flight is marked as Favority, so you can also navigate from Bottom (in Portrait Mode)
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageFive.qml" line="64"/>
        <source>Activation Policy: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageFive.qml" line="71"/>
        <source>IMMEDIATELY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageFive.qml" line="85"/>
        <source>Init done from Flight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageFive.qml" line="89"/>
        <source>Cleanup done from Flight</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageFour</name>
    <message>
        <location filename="../pages/PageFour.qml" line="25"/>
        <source>Hello Truck Driver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageFour.qml" line="39"/>
        <source>Example APP demonstrating Qt Quick Controls 2

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageFour.qml" line="47"/>
        <source>Truck is a normal page.
Navigation Drawer can be opened swiping from left or tapping on Menu Button.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageFour.qml" line="56"/>
        <source>Activation Policy: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageFour.qml" line="63"/>
        <source>LAZY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageFour.qml" line="77"/>
        <source>Init done from Truck</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageFour.qml" line="81"/>
        <source>Cleanup done from Truck</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageOne</name>
    <message>
        <location filename="../pages/PageOne.qml" line="27"/>
        <source>Drive by Car</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageOne.qml" line="36"/>
        <location filename="../pages/PageOne.qml" line="46"/>
        <source>Available Cars: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageOne.qml" line="57"/>
        <source>Example APP demonstrating Qt Quick Controls 2

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageOne.qml" line="65"/>
        <source>Car is a normal Page with a Counter visible in Drawer. Counter can be increased tapping on the &apos;add&apos; Icon above.
Navigation Drawer can be opened swiping from left or tapping on Menu Button.
Car is marked as Favority, so you can also navigate from Bottom (in Portrait Mode)
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageOne.qml" line="74"/>
        <source>Activation Policy: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageOne.qml" line="81"/>
        <source>LAZY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageOne.qml" line="96"/>
        <source>Init done from Car</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageOne.qml" line="100"/>
        <source>Cleanup done from Car</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageThree</name>
    <message>
        <location filename="../pages/PageThree.qml" line="25"/>
        <source>GoTo next Subway Station</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageThree.qml" line="47"/>
        <source>Example APP demonstrating Qt Quick Controls 2

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageThree.qml" line="56"/>
        <source>Subway is a normal Page.
Navigation Drawer can be opened swiping from left or tapping on Menu Button.
Subway has a colored Marker in Drawer
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageThree.qml" line="65"/>
        <source>Activation Policy: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageThree.qml" line="72"/>
        <source>WHILE SELECTED</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageThree.qml" line="86"/>
        <source>Init done from Subway</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageThree.qml" line="90"/>
        <source>Cleanup done from Subway</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageTwo</name>
    <message>
        <location filename="../pages/PageTwo.qml" line="25"/>
        <source>Take a Bus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageTwo.qml" line="39"/>
        <source>Example APP demonstrating Qt Quick Controls 2

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageTwo.qml" line="48"/>
        <source>Bus is a normal Page.
Navigation Drawer can be opened swiping from left or tapping on Menu Button.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageTwo.qml" line="57"/>
        <source>Activation Policy: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageTwo.qml" line="64"/>
        <source>LAZY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageTwo.qml" line="78"/>
        <source>Init done from Bus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PageTwo.qml" line="82"/>
        <source>Cleanup done from Bus</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrimaryColorPage</name>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="23"/>
        <source>Select Material Primary Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="63"/>
        <source>Material Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="64"/>
        <source>Material Pink</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="65"/>
        <source>Material Purple</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="66"/>
        <source>Material DeepPurple</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="67"/>
        <source>Material Indigo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="68"/>
        <source>Material Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="69"/>
        <source>Material LightBlue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="70"/>
        <source>Material Cyan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="71"/>
        <source>Material Teal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="72"/>
        <source>Material Green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="73"/>
        <source>Material LightGreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="74"/>
        <source>Material Lime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="75"/>
        <source>Material Yellow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="76"/>
        <source>Material Amber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="77"/>
        <source>Material Orange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="78"/>
        <source>Material DeepOrange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="79"/>
        <source>Material Brown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="80"/>
        <source>Material Grey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="81"/>
        <source>Material BlueGrey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="92"/>
        <source>Init done from PrimaryColorPage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/PrimaryColorPage.qml" line="96"/>
        <source>Cleanup done from PrimaryColorPage</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtPage</name>
    <message>
        <location filename="../pages/QtPage.qml" line="26"/>
        <source>The Qt Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/QtPage.qml" line="37"/>
        <source>Going Back to Home Page ?
Tap on the green Arrow to pop() the Page.
In a real-live APP the TitleBar should show the BACK Button. (Android BACK Button is implemented)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/QtPage.qml" line="65"/>
        <source>Example APP demonstrating Qt Quick Controls 2

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/QtPage.qml" line="80"/>
        <source>Init done from QtPage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/QtPage.qml" line="84"/>
        <source>Cleanup done from Qt Page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SettingsPage</name>
    <message>
        <location filename="../pages/SettingsPage.qml" line="30"/>
        <source>Settings Drawer Navigation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/SettingsPage.qml" line="43"/>
        <source>Settings is a normal Page.
Navigation Drawer can be opened swiping from left or tapping on Menu Button.
Settings is marked as favorite, so can be opened from Bottom Navigation (in Portrait Mode)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/SettingsPage.qml" line="52"/>
        <source>Activation Policy: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/SettingsPage.qml" line="59"/>
        <source>WHILE SELECTED</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/SettingsPage.qml" line="68"/>
        <source>Highlight Active Navigation Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/SettingsPage.qml" line="79"/>
        <source>Hide TitleBar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/SettingsPage.qml" line="90"/>
        <source>Show Favorites at Bottom in Portrait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/SettingsPage.qml" line="110"/>
        <source>Init done from SettingsPage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/SettingsPage.qml" line="114"/>
        <source>Cleanup done from SettingsPage</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SimpleTextTitle</name>
    <message>
        <location filename="../common/SimpleTextTitle.qml" line="39"/>
        <source>Light Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../common/SimpleTextTitle.qml" line="39"/>
        <source>Dark Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../common/SimpleTextTitle.qml" line="45"/>
        <source>Select Primary Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../common/SimpleTextTitle.qml" line="52"/>
        <source>Select Accent Color</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StackTextTitle</name>
    <message>
        <location filename="../common/StackTextTitle.qml" line="52"/>
        <source>Light Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../common/StackTextTitle.qml" line="52"/>
        <source>Dark Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../common/StackTextTitle.qml" line="58"/>
        <source>Select Primary Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../common/StackTextTitle.qml" line="65"/>
        <source>Select Accent Color</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SwipeTextTitle</name>
    <message>
        <location filename="../common/SwipeTextTitle.qml" line="53"/>
        <source>Light Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../common/SwipeTextTitle.qml" line="53"/>
        <source>Dark Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../common/SwipeTextTitle.qml" line="59"/>
        <source>Select Primary Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../common/SwipeTextTitle.qml" line="66"/>
        <source>Select Accent Color</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ThemePage</name>
    <message>
        <location filename="../pages/ThemePage.qml" line="22"/>
        <source>Select your Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/ThemePage.qml" line="25"/>
        <source>Dark Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/ThemePage.qml" line="44"/>
        <source>Init done from Theme Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/ThemePage.qml" line="48"/>
        <source>Cleanup done from Theme Page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="170"/>
        <location filename="../main.qml" line="186"/>
        <source>From Drawer to Destinations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="259"/>
        <source>Next BACK closes APP and clears Values

Use &apos;Android Home&apos; Button for Fast-Restart.

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="352"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
