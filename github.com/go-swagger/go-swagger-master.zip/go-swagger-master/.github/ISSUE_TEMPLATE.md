## Problem statement

Please remove the sections that don't apply

## Swagger specification

## Steps to reproduce

## Environment
swagger version: x.x.x  
go version: x.x.x  
OS:   
